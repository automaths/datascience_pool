from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
    description='A sample test package',
    url='',
    author='eagle',
    Home-page:'https://github.com/eagle/ft_package',
    Author-email:'eagle@42.fr',
    license='MIT',
    Location:'/home/eagle/...',
    Requires:'',
    Required-by:'',
    Metadata-Version:'2.1',
    Installer:'pip',
    Classifiers:'',
    Entry-points:'',
)
