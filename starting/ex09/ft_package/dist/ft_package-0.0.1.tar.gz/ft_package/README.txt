# mypackage

A simple 42 Python package

## Installation

You can install this package using pip:

```bash
pip install mypackage