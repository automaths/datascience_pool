from sys import argv


def count_in_list(lst: string, item: string) -> int:
    """Count the number of times item occurs in lst."""
    return lst.count(item)
